# Automaticattendancesystem
It is an AI based system which uses Local Binary Pattern Histogram(LBPH) algorithm to detect and recognize the face for attendance. 
Mainly focusing on the goal to remove the traditional attendance system of colleges.  
